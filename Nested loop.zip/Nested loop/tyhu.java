/**
 * 
 */
import java.util.*;
public class tyhu
{
    public static void main()
    {
        int ch,i,j;
        Scanner sc = new Scanner(System.in);
         do
        {
            
    System.out.println("ENTER 1 FOR PAT 1 \n ENTER 2 FOR PAT 2 \n ENTER 3 FOR PAT 3 \n ENTER 4 FOR PAT 4 \n ENTER 5 FOR PAT 5 ");
    ch=sc.nextInt();
    switch(ch)
    {
        case 1:
            for(i=1;i<=5;i++)
            {
                for(j=i;i>=1;j--)
                {
                    System.out.print(j+" ");
                }
                System.out.println(" ");
            }
            case 2:
            for(i=5;i<=5;i--)
            {
                for(j=1;i>=1;j++)
                {
                    System.out.print(j+" ");
                }
                System.out.println(" ");
            }
            case 3:
            for(i=5;i<=;i--)
            {
                for(j=1;i<=1;j++)
                {
                    System.out.print(j+" ");
                }
                System.out.println(" ");
            }
    }
    }
}