/**
    1 
   12 
  123 
 1234 
12345 
    i           j           k       out
    1           4-1        1-1        1
    2           4-2        1-2       12
    3           4-3        1-3      123
    4           4-4        1-4     1234 
    5           0          1-5    12345  

 */

public class k13
{
    public static void main()
    {
        int i,j,k;
        for(i=1;i<=5;i++)
        {
            for(j=5-i;j>=1;j--)
            {
                System.out.print(" ");
                
            }
            for(k=1;k<=i;k++)
            {
                 System.out.print(k);
                 
            }
             System.out.println(" ");
        }
    }
}