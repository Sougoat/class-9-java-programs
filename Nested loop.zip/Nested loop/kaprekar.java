/**
 * wap to accept a number and check wheather it is a kaprikar number or not
 * kaprekar number = it is a number whose square in that base can be split into two parts that add up to the original number
    ex  45=45*45=2025=  20+25=45   
*/

import java.util.*;
public class kaprekar
{
    int Sumd(int n)
    {
        int c=0;
        while(n>0)
        {
            c++;
            n=n/10;
        }
        return c;
    }
    void main()
    {
        int t;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER A NUMBER");
        t=sc.nextInt();
        int sq = t*t;
        int a = sq%(int)(Math.pow(10,Sumd(t)));
        int b = sq/(int)(Math.pow(10,Sumd(t)));
        if((a+b)==t)
        {
        System.out.println(t+" is  A  kaprekar NUMBER");
        }
        else
        {
            System.out.println(t+" is not  A  kaprekar NUMBER");
        }
    }
}
