/**
 * WAP IN JAVA ATO DISPLAY THE FOLOWING PATTERN ACCCORFDING TO USERS CHOICE
 * CH 1 :
1  
2 1  
3 2 1  
4 3 2 1  
5 4 3 2 1  
 * 
  
 * CH 2 : 
 * 
1 2 3 4 5  
1 2 3 4  
1 2 3  
1 2  
1

CH 3:
5 4 3 2 1  
5 4 3 2  
5 4 3  
5 4  
5 

CH 4:

1 3 5 7 9  
1 3 5 7  
1 3 5  
1 3  
1


CH 5:

5  
5 4  
5 4 3  
5 4 3 2  
5 4 3 2 1  
 */
import java.util.*;
class pat1
{
    public static void main()
    {
        int i,j,ch;
        
        Scanner sc = new Scanner(System.in);
        do
        {
            
            System.out.println("ENTER 1 FOR PAT 1 \n ENTER 2 FOR PAT 2 \n ENTER 3 FOR PAT 3 \n ENTER 4 FOR PAT 4 \n ENTER 5 FOR PAT 5 ");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
                for(i=1;i<=5;i++)
                {
                    for(j=i;j>=1;j--)
                    {
                        System.out.print(j+" ");
                        
                    }
                    System.out.println(" ");
                }
                break;
                case 2:
                for(i=5;i>=1;i--)
                {
                    for(j=1;j<=i;j++)
                    {
                        System.out.print(j+" ");
                        
                    }
                    System.out.println(" ");
                }
                break;
                case 3:
                for(i=1;i<=5;i++)
                {
                    for(j=5;j>=i;j--)
                    {
                        System.out.print(j+" ");
                        
                    }
                    System.out.println(" ");
                }
                break;
                case 4:
                for(i=9;i>=1;i-=2)
                {
                    for(j=1;j<=i;j+=2)
                    {
                        System.out.print(j+" ");
                        
                    }
                    System.out.println(" ");
                }
                break;
                case 5:
                for(i=5;i>=1;i--)
                {
                    for(j=5;j>=i;j--)
                    {
                        System.out.print(j+" ");
                        
                    }
                    System.out.println(" ");
                }
                break;    
                
                default:System.out.println("WRONG CHOICE TRY AGAIN");
                
                
        }
    }while(ch!=0);
}
}