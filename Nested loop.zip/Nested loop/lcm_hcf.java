/**
 * WAP TO JAVA TO ACCEPT TWO NUMBERS AND CALCULATE THE HCF AND LCM OF BOTH THE NUMBERS
 * IN:- 30,18/12,48
 * OUT:- HCF - 6 AND LCM - 90
 * OUT - HCF - 12 AND LCM - 48
 */
import java.util.*;
public class lcm_hcf
{
    public static void main()
    {
        int m,n,hcf=0,lcm=0;
        Scanner sc=new Scanner(System.in); 
        System.out.println("enter the first number");
        m=sc.nextInt();
        System.out.println("enter the second number");
        n=sc.nextInt();
        m=(int)Math.min(m,n);
        m=(int)Math.max(m,n);
        for(int i=1;i<=m;i++)
        {
           if(m%i==0 && n%i==0)
           hcf=i;
        }
        lcm=(m*n)/hcf;
        System.out.println("the hcf of two numbers is "+hcf);
        System.out.println("the lcm of two numbers is "+lcm);
    }
}