/**
 * 12345
 *  2345 
 *   345
 *    45
 *     5
 */
public class k4
{
    public static void main()
{
    int i,j,sp=0,k;     
    for(i=1;i<=5;i++)
    {
        for(j=1;j<=sp;j++)
        System.out.print(" ");
        for(k=i;k<=5;k++)
        System.out.print(k);
        sp++;
        System.out.println();
    }
}
}
