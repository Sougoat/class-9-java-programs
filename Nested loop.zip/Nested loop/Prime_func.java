/** WAP TO ACCEPT A NUMBER AND CHECK WHETHER THE NUMBER IS A PRIME NUMBER OR NOT USING FUNCTION
 * EX - 3 7 13 
 */

public class Prime_func
{
    boolean isPrime(int n)
    {
        int i,c=0;
        for(i=1;i<=n;i++)
        {
            if(n%i==0)
            c++;
            
        }
        if(c==2)
        return true;
        return false;
        
    }
}