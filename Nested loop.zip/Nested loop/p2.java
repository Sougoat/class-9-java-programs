/**
 * Wap to accept a number and display the sum of each digit, raised to the power of the number of digits.
 * in :- 49=4^2+9^2=16+81=97
 * in - 146=1^3+4^3+6^3=1+64+216=281
 */
import java.util.*;
public class p2
{
    public static void main()
    {
        int c=0,d=0,k=0,n,t,s=0,i;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number ");
        n=sc.nextInt();
        t=n;
        for(i=t;t>0;t=t/10)
        {        
            d=t%10;
            c++;
        }
        System.out.println("the no of digits in the original no is "+c);
        for(i=n;n>0;n=n/10)
        {       
            k=n%10;
            s=s+(int)(Math.pow(k,c));
            
        }
        System.out.println("The sum is >> "+s);
    }
}