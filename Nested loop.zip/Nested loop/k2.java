/**
 * display the pattern
1
12
123
1234
12345

 */
public class k2
{
    public static void main()
    {
        int i,j;
        for(i=1;i<=5;i++)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print(j);
                
            }
            System.out.println();
        }
    }
}


/**     inner loop - j
 *      i               j               out
 *      1               1-1             1
 *      2               1-2             12
 *      3               1-3             123
 *      4               1-4             1234
 *      5               1-5             12345
 */




