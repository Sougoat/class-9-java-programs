/**
 * WAP TO ACCCEPT A NUMBER AND DISPLAY THE NEW NUMBER AFTER REVERSING THE DIGITS OF THE ORIGINAL NUMBER AND
 * DISPLAY THE ABSOLUTE DIFFERENCE BETWEEN THE ORIGINAL NUMBER AND THE REVERSE NUMBER
 */
import java.util.*;
public class reverse
{
    public static void main()
    {
        int n,d,r=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER A NUMBER");
        n=sc.nextInt();
        int e;
        e=n;
        while(n>0)
        {
            d=n%10;
            r=(r*10)+d;
            n=n/10;
        }
        double k=Math.abs(r-e);
        System.out.println("the original number is "+e);
        System.out.println("the reverse of number is "+r);
        System.out.println("the abselute differnce between the original and reverse number is "+k);
    }
}