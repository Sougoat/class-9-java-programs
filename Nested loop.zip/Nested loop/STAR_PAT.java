/**
 * WAP IN JAVA TO DISPLAY THE FOLLOWING PATTERN ACCORDING TO USERS CHOICE
 * I) 1 FOR TRIANGLE
*  * 
*  * * 
*  * * * 
*  * * * *
*  * * * * *
                                I               J               OUT
                                1               1-1                *
                                2               1-2                **
                                3               1-3                ***
 * II) FOR INVERTED TRIANGLE
   * * * * * 
   * * * * 
   * * * 
   * * 
   *
                                I               J               OUT
                                5               1-5                *****
                                4               1-4                ****
                                3               1-3                ***
    */

import java.util.*;
public class STAR_PAT
{
    public static void main()
    {
        int n,i,j,ch;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER 1 FOR TRIANGLE \n ENTER 2 FOR INVERTED TRIANGLE");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
                for(i=1;i<=5;i++)
                {
                    for(j=1;j<=i;j++)
                    {
                        System.out.print("* ");
                    }
                    System.out.println();
                    
                }
                break;
                case 2:
                for(i=5;i>=1;i--)
                {
                    for(j=1;j<=i;j++)
                    {
                        System.out.print("* ");
                    }
                    System.out.println();
                    
                }
                break;
                default:
                    System.out.println("WRONG CHOICE TRY AGAIN");
                
        }
    }
}