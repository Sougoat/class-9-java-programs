/**
 * WAP TO ACCEPT A NUMBER AND CHECK WHEATHEWR THE NUMBER IS A WEAK ARMSTRONG NUMNBER OR NOT
 * WEAK ARMSTRONG IS A NUMBER WHERE THE SUM OF THE POSITION RAISED TO THE POWER OF EACH DIGIT = ORIGINAL NO
 * EX- 135=1^1+3^2+5^3 = 1+9+125=135
 */
import java.util.*;

public class weak_arm
{
    public static void main()
    {
        int n,d,s=0,t=3;
        double g = 0.0;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter a no");
        n=sc.nextInt();
        int p=n;
        while(n>0)
        {
            d=n%10;
            g=Math.pow(d,t);
            s=s+(int)g;
            n=n/10;
            t--;
        }
        
        System.out.println(s);
        if(s==p)
        {
               System.out.println(p+"is a weak armstrong number");
        }
        else
        {
            System.out.println(p+"is  not a weak armstrong number");
        }
    }
}
        
        
        
        
        
        
        