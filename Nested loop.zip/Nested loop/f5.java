/**
 * 1/(x+3)!+4/(x+6)!+...16/(x+18)!
 */
import java.util.*;
public class f5
{
    double Fact(double n)
    {
        int i;
        double f = 1.0;
        for(i=1;i<=n;i++)
        {
            f=f*i;
        }
        return f;
    }
    void main()
    {
        int i;
        double s=0.0,x=0.0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the value of x");
        x=sc.nextDouble();
        for(i=1;i<=16;i=i+3)
        {
            s=s+(double)((i)/(Fact(x+(i+2.0))));
        }
        System.out.println("the sum of the series is "+s);
    }
    }