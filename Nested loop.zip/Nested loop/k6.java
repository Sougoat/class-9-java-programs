/**
 * WAP to display the Following according to User's Choice :
 * i)      5 55 555 5555 55555 555555     
 * ii)        #
 *            **
 *            ###
 *            **
 *            #####
 */
import java.util.*;
public class k6
{
    public static void main()
    {
        char ch=' ';
        Scanner in=new Scanner(System.in);  
        System.out.print("Enter 'a' for Star Pattern.\nEnter 'b' for String Pattern.\nEnter Choice : ");
        ch=in.next().charAt(0);
        switch(ch)
        {
            case 'a':
                for(int i=1;i<=6;i++)  
                {
                    for(int j=1;j<=i;j++)
                        System.out.print(5);
                    System.out.print(' ');
                }
                break;
            case 'b':
                for(int i=1;i<=5;i++)      
                {
                    for(int j=1;j<=i;j++)
                        System.out.print((((i%2)==0)?'*':'#'));
                    System.out.println();
                }
                break;
        }
    }
}