/**
1
 00
  111
   0000
    11111


i           j           k       out
1           4           1-1         1
2           3           1-2        00    
3           2           1-3       111     

 */
public class k8
{
   public static void main()
   {
       int i,j,k,sp=0;
       for (i=1;i<=5;i++)
       {
           for(j=1;j<=sp;j++)
           {
               System.out.print(" ");
           }
           for(k=1;k<=i;k++)
           {
               System.out.print(j%2);
               
           }
           sp++;
           System.out.println();
       }
   }
}