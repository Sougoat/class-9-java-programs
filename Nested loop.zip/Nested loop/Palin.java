/**
 * Wap to accept a number and check whether the number is Palindromic or not
 * Palindromic no = It is a Prime number and when it is reversed it results the same original number and prime
 * ex = 131
 */
import java.util.*;
public class Palin
{
    
          
        int Rev(int t)
        {
            int d,r=0;
            while(t>0)
            {
                d=t%10;
                r=(r*10)+d;
                t=t/10;
           }
           return r;
        }
        public void main()
        {
            int k;
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter a number ");
            k=sc.nextInt();
            int t=k;
            if(Rev(k)==t)
            {
                System.out.println(k+" is a Palindromic number");
            }
            else
            {
                   System.out.println(k+" is not a Palindromic number");
            }
           
            }
        }
    
     
    
    
    
  