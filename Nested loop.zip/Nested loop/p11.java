/**
1 2 3 4 5  
6 7 8 9  
10 11 12  
13 14  
15  
        i           j           out
        5          1-5         1 2 3 4 5
        4          1-4         6 7 8 9
        3          1-3         10 11 12
        
 */


public class p11
{
    public static void main()
    {
        int i,j,a=1;
        for(i=5;i>0;i--)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print(a+" ");
                    a++;
                }
               
             System.out.println(" ");
        }
    }
}