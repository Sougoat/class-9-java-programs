 /**
 * WAP IN JAVA ATO DISPLAY THE FOLOWING PATTERN ACCCORFDING TO USERS CHOICE
 * CH 1 :
1  
2 1  
3 2 1  
4 3 2 1  
5 4 3 2 1  
 * 
  
 * CH 2 : 
 * 
1 2 3 4 5  
1 2 3 4  
1 2 3  
1 2  
1

CH 3:
5 4 3 2 1  
5 4 3 2  
5 4 3  
5 4  
5 

CH 4:

1 3 5 7 9  
1 3 5 7  
1 3 5  
1 3  
1


CH 5:

5  
5 4  
5 4 3  
5 4 3 2  
5 4 3 2 1  
 */  
import java.util.*;
public class ijdiw
{
    public static void main 
    
        
    
        int i,j;
        for(i=1;i<=5;i++)
         {
             for(j=i;j>=1;j--)
             {
                        System.out.print(j+" ");
                        
                    }
                    System.out.println(" ");
                }
    }
}