//A program to display the pattern
/*
 * q        a       b       out
 * 1        1       1-1     1
 * 3        2       1-2     3  5
 * 5        3       1-3     7   9   11
 * 
 * 
 */
public class pattern
{
    public static void main()
    {
        int a,b,p,q=1;
        System.out.println("The pattern");
        for(a=1;a<=5;a++)
        {
            p=q;
            for(b=1;b<=a;b++)
            {
                System.out.print(p+" ");
                p=p+2;
            }
            q=q+2;
             System.out.println();
        }
        
    }
}