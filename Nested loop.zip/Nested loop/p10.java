/**
1 
31 
531 
7531 
97531 
        i           j           out
        1           1           1
        3           3-1         31
        5           5-1         531
        7           7-1         7531
 */


public class p10
{
    public static void main()
    {
        int i,j;
        for(i=1;i<10;i=i+2)
        {
            for(j=i;j>0;j=j-2)
            {
                System.out.print(j);
                    
                }
               
             System.out.println(" ");
        }
    }
}