/**
 * wap to accept a number and check wheather it is a magic number or not
 * magic_number = a number is a magic if the eventual sum of digits of the number is 1
 * 55=5+5=10=1+0=1
 * 19=1+9=10=1+0=1
 */
import java.util.*;
public class magic_number
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,d,sum;
        System.out.println("ENTER A NUMBER");
        n=sc.nextInt();
        int num=n;
        while(num>9)
        {
            sum=0; 
            while(num>0)
            {
                d=num%10;
                sum=sum+d;
                num=num/10;
            }
            num=sum;
        }
        if(num==1)
        System.out.println(n+" is a magic number");
        else
        System.out.println(n+" is  not a magic number");
        }
    }