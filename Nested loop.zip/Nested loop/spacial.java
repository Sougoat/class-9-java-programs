/**
 * WAP TO ACCEPT ANUMBER AND CHECK WHEATHER IT IS A SPEACIAL  TWO DIGIT NUMBER OR NOT
 * SPACIAL TWO DIGIT NUMBER = IT IS A NUMBER WHERE THE SUM OF ITS DIGITS IS ADDED PRODUCT OF ITS DIGITS IS EQUAL TO THE ORIGINAL NUMBER
 * 59 = (5*9)+(5+9)=45+14=59
 */

import java.util.*;
public class spacial
{
    public static void main()
    {
        int n,p=1,s=0,t=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER A NUMBER");
        n=sc.nextInt();
        int num = n;
        while(n>0)
        {
            int d=n%10;
            s=s+d;
            p=p*d;
            n=n/10;
        }
        t=s+p;
        if (t==num)
        {
            System.out.println(num+" is a spacial two digit number");
        }
        else
        {
                System.out.println(num+" is not a spacial two digit number");
        }
    }
}