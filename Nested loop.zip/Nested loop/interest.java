/**
 * USING THE SWITCH SRTATEMENT WRITE A MENU RIVEN PROGRAM TO CALCULATE THE MATURITY AMAOUNYT OF A BANK DEPOSIT
 * THE USER IS GIVEN THE FOLLOWING OPTIONS
 * I) TERM DEPOSIT
 * II) RECURRING DEPOSIT 
 * FOR OPTION I ACCVEPT PRINCICPAL(P), RATE OF INTEREST(R) AND TIME PERIOD(IN YEARS N) CALCULATE AND OUTPUT THE MATURITY AMAOUNT(A)
 * RECIEVABLE USING THE FORMULA A=P(1+R/100)N
 * II) FOR OPTION 2 ACCEPT MONTHLY INSTALLMENT(P) RATE OF INTEREST(R) AND TIME PERIOID IN MONTHS(N)
 * CALCULATE AND OUTPUT THE MATURITY AMAOUNT(A)
 * RECIEVABLE USING THE FORMULA A=P*N+P*[N(N+1)]/2*R/100*1/12
 * FOR AN INCORRECT OPTION AN APPROPRIATE EROOR MESSAGE SHOULD BE DISPLAYED
 */
import java.util.*;
public class interest
{
    public static void main()
    {
        int n,ch,p;
        double r,a=0.0;
        Scanner sc = new Scanner(System.in);
        do
        {
        System.out.println("ENTER 1 FOR OPTION 1 \n ENTER 2 FOR OPTION 2");
        ch=sc.nextInt();
        System.out.println("ENTER the principal amount");
        p=sc.nextInt();
        System.out.println("ENTER the rate of interest ");
        r=sc.nextDouble();
        System.out.println("ENTER the time ");
        n=sc.nextInt();
        switch(ch)
        {
            case 1:
            
            a=p*Math.pow(1.0+(r/100.0),n);
            System.out.println("the amount under term deposit is "+a);
            break;
            case 2:
                a=p*n+p*(n*(n+1.0))/2.0*r/100.0*1.0/12.0;
                System.out.println("the amount under Recurring deposit is "+a);
            break;
            default: System.out.println("Wrong choice, try again ");
            
        }
    }while(ch!=0);
}
}