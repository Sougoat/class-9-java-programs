public class rg
{
   public static void main()
   {
       double m=6.25;
       double n=7.45;
       System.out.println(Math.sqrt(m));
       System.out.println(Math.min(m,n));
       System.out.println(Math.abs(m-n));
       System.out.println(Math.ceil(m));
    }
}