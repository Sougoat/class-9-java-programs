/**
 * Wap to accept a number and display the sum of each digit, raised to the power of the number of digits. */
import java.util.*;
public class p1
{
    public static void main()
    {
        int c=0,d=0,k=0,n,t,s=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number ");
        n=sc.nextInt();
        t=n;
        while(t>0)
        {
            t=t/10;
            c++;
        }
        System.out.println("the no of digits in the original no is "+c);
        while(n>0)
        {
            k=n%10;
            s=s+(int)(Math.pow(k,c));
            n=n/10;
        }
        System.out.println("The sum is >> "+s);
    }
}