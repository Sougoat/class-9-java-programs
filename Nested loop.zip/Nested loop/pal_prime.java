/**
 * WAP TO PRINT ALL THE PAL PRIME NUMBERS FROM 1 TO 500
 * PAL PRIME NUMBER IS A PRIME NUMBER WHICH AND WHEN REVERSED ALSO DISPLAY A PRIME NUMBER
 * 137
 * 731
*/
import java.util.*;
public class pal_prime
{
    boolean isPrime(int n)
    {
        int i=1,c=0;
        for(i=1;i<=n;i++)
        {
            if(n%i==0)
            c++;
        }
        if(c==2)
        return true;
        return false;
    }
    
     int isRev(int a)
    {
        int r=0,n=a,i;
        while(a>0)
        {
            int d=a%10;
            r=(r*10)+d;
            a=a/10;
            
        }
        return r;
        }
        
        void main()
        {
            int i;
            int n;
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter a number ");
            n=sc.nextInt();
            pal_prime ob=new pal_prime();
            
                if(isPrime(n)==true && isPrime(isRev(n))==true)
                System.out.println(n+" is a prime palindromic number");
                else
                System.out.println(n+" is not a prime palindromic number");
                
            }
           
        }
   
    
