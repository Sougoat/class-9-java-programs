/**
 * Wap to accept a number and check whether it is a Twisted prime no / Enrip number or not
 * Twisted Prime = It is a prime number which and when reversed results in another prime number
 * EX=13 Reversed no =31
 * 79 = 97
 */
import java.util.*;
public class Twisted_Prime
{
    boolean isPrime(int n)
    {
        int i,c=0;
        for(i=1;i<=n;i++)
        {
            if(n%i==0)
            c++;
            
        }
        if(c==2)
        return true;
        return false;
    }
    int Rev(int t)
    {
        int d,rev=0;
        while(t>0)
        {
            d=t%10;
            rev=(rev*10)+d;
            t=t/10;
        }
        return rev;
    }
    
    void main()
    {
        int x;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        x=sc.nextInt();
        
        if(isPrime(x)==true && isPrime(Rev(x))==true)
        System.out.println(x+" is a Twisted Prime number");
        else
        System.out.println(x+" is not a Twisted Prime number");
    }
        
    }
    
    
    
    
    
    
    

