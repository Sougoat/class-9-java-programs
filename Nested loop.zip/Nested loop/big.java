/**
 * FIND THE BIGGEST DIGIT OF AN INTGER INPUT BY HE USER 
 * 6524 = SMALLEST DIGIT IS 6
 * 
 */
import java.util.*;
public class big
{
    public static void main()
    {
        int i,ch,d,n,c=0;
        Scanner sc = new Scanner(System.in);
               System.out.println("ENTER A NUMBER");
               int t=sc.nextInt();
               int k=t;
               int big=k%10;
               while(k>0)
                   {
                       d=k%10;
                       if(d>big)
                       big=d;
                       k=k/10;
                    }    
                     System.out.println("the biggest digit is "+big);  
                    }
                        
                
               
                   }
                   
                   
                   
                   
                   
                   
                   
                   
            
        