/** display the pattern
1
12
123
1234
12345

 */
public class ytyh
{
    public static void main()
    {
        int i,r;
        for(i=1;i<=5;i++)
        {
            
            for(r=1;r<=i;r++)
            {
                System.out.print(i);
            }
            System.out.println();
        }
    }
}