/**
 * WAP IN JAVA TO REVERSE A NUMBER AND FIND ITS SUM USING DO WHILE LOOP
 */
import java.util.*;
public class T1987
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,d,r=0,sum=0;
        System.out.println("Enter a number");
        n=sc.nextInt();
        do
        {
            d=n%10;
            r=(r*10)+d;
            sum=sum+d;
            n=n/10;
        }while(n>0);
        System.out.println("the reverse of the number is "+r);
        System.out.println("sum of the digits is "+sum);
    }
}