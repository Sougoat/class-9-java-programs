/**
 * WRITE A MENU DRIVEN PROGRAM TO DISPLAY THE FOLLOWING
 * I) (1*2)+(2*3)+...(19*20)
 * II) WAP TO CHECK WHWEATHER A NUMBER HAS A EVEN OR ODD NUMBER OF DIGITS
 */
import java.util.*;
public class EVEN_ODD_NO
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,sum=0,ch,d=0,n;
         System.out.println("ENTER 1 FOR OPTION 1 \n ENTER 2 FOR OPTION 2");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
                for(i=1;i<=19;i++)
                {
                    sum=sum+i*(i+1);
                }
                System.out.println("THE SUM IS  "+sum);
                break;
                case 2:
                
                System.out.println("ENTER A NUMBER ");
                n=sc.nextInt();
                while(n>0)
                {
                    d++;
                    n=n/10;
                }
                System.out.println("THE NUMBER OF DIGITS OF THE NUMBER IS "+d);
                if(d%2==0)
                System.out.println("THE NUMBER CONTAINS EVEN NUMBER OF DIGITS ");
                else
                System.out.println("THE NUMBER CONTAINS ODD NUMBER OF DIGITS ");
                break;
                default: System.out.println("WRONG CHOICE TRY AGAIN");
        }
    }
}