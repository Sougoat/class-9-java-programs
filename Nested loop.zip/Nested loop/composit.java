/**
 * USING SWITCH STATEMENT WRITE A MENU DRIVEN PROGRAM 
 * I] CHECK AND DISPLAY WHEATHER A NUMBER INPUT BY THE USER IS A COMPOSIT NUMBERV OR NOT
 * COMPOSIT NUMBER = IF THE NUMBER HAS ONE OR MORE FACTORS EXCLUDING 1 AND THE NUMBER ITSELF
 * EX= 4 8 12 ETC
 * II] FIND THE SMALLEST DIGIT OF AN INTGER INPUT BY HE USER 
 * 6524 = SMALLEST DIGIT IS 2
 * 
 */
import java.util.*;
public class composit
{
    public static void main()
    {
        int i,ch,d,n,c=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER 1 FOR COMPOSIT \n ENTER 2 FOR SMALLEST DIGIT");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
               System.out.println("ENTER A NUMBER");
               n=sc.nextInt();
               for(i=1;i<n;i++)
               {
                   if(n%i==0)
                      c++;
                    } 
                        if(c>2)
                        System.out.println(n+" is a composit number");
                        else
                        System.out.println(n+" is a prime number");
               break;
               case 2:
               System.out.println("ENTER A NUMBER");
               int t=sc.nextInt();
               int k=t;
               int min=k%10;
               while(k>0)
                   {
                       d=k%10;
                       if(d<min)
                       min=d;
                       k=k/10;
                    }    
                     System.out.println("the smallst digit is "+min);  
                     break;
                     default:
                         System.out.println("Wrong choice try again");
                        }
                        
                
               
                   }
                   
                   
                   
                   
                   
                   
                   
                   
               }
        