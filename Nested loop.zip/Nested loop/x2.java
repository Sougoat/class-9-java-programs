public class x2
{
    public static void main()
    {
        int i=1,f=1;
        while(i<=5)
        {
            f=f*i;
            i++;
        }
        System.out.println("The value of f is >> "+f);
    }
}

