/**
 * write a menu driven program to display the following pattern   
 * i)    12345
 *       2345
 *       345
 *       45
 *       5
 *  ii)         6
 *             56
 *            456
 *           3456
 *          23456
 *         123456
 *   
 */
import java.util.*;
public class bs1
{
    public static void main()
    {
        int i,j,ch,l,sp,k;
        do
        {
            Scanner sc = new Scanner(System.in);
            System.out.println("ENTER 1 FOR PATTERN 1 \n ENTER 2 FOR PATTERN 2");
            ch=sc.nextInt();
            switch(ch)
            {
                case 1:
                  System.out.println("ENTER THE LIMIT");
                  l=sc.nextInt();
                  for(i=1;i<=l;i++)
                  {
                      for(j=1;j<=l-i+1;j++)
                      {
                          System.out.print(j);
                      }
                      System.out.println("");
                  }
                  break;
                  case 2:
                  System.out.println("ENTER THE LIMIT");
                  l=sc.nextInt();
                  sp = l-1;
                  
                  for(i=l;i>=1;i--)
                  {
                      for(j=1;j<=sp;j++)
                      System.out.print(" ");
                      for (k=i;k<=l;k++)
                          System.out.print(k);
                      
                      System.out.println("");
                      sp--;
                  }
                  break;
                  
            }
            
        } while(ch!=0);
    }
}

