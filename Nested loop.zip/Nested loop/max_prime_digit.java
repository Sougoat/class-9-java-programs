/**
 * WAP TO ENTER A NUMBER AND DISPLAY THE MAXIMUM PRIME DIGIT
 */

import java.util.*;

public class max_prime_digit
{
    public static void main()
    {
        int n,d,big=0,c=0,i;
        Scanner ob=new Scanner(System.in);
        System.out.println("enter a no");
        n=ob.nextInt();
        do
        {
            d=n%10;
            for(i=1;i<=d;i++)
            {
               
                {
                 if(d%i==0)
                 c++;
                }
                if(c==2)
                {
                    if(big<d)
                    big=d;
                }
                c=0;
                n=n/10;
            }
            c=0;
            n=n/10;
        }while(n!=0);
        System.out.println(big+" is the maximum prime digit");
    }
}