/**
 * THE INTERNATIONAL STANDARD BOOK NUMBERE ISBN IS A UNIQUE NUMERIC BOOK IDENTIFIER WHITCH IS PRINTED ON EVERY BOOK
 *  THE ISBN IS BASED UPON A 10 DIGIT CODE 
 *  ISBN = 1*DIGIT1+2*DIGIT2+3*DIGIT3+....................10*DIGIT10 IS DIVISABLE BY 11 EXAMPLE - 1401601499
 *  
 */
import java.util.*;
public class ISBN
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i,n,d,sum=0,p;
        System.out.println("ENTER A 10 DIGIT CODE");
        n=sc.nextInt();
        p=n;
        for(i=10;i>=1;i--)
        {
            d=n%10;
            sum=sum+(d*i);
            n=n/10;
            
        }
        if (sum%11==0)
        {
            System.out.println(p+" is a isbn number");
        }
        else
        {
              System.out.println(p+" is not a isbn number");
        }
    }
}