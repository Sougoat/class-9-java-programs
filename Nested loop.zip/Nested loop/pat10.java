/**
 * WAP TO DISPLAY THE FOLLOWING SERIES ACCORDING TO USERS CHOICE
 * 
 * I)
 *    1
 *    31
 *    531
 *    7351
 *    97531
 * II)
 *        1 2 3 4 5
 *        6 7 8 9
 *        10 11 12
 *        13 14
 *        15
 * III)
 *     15 15 13 12 11
 *     10 9 8 7
 *     6 5 4
 *     3 2
 *     1
 * IV)
 *     1
 *     10
 *     101
 *     1010
 *     10101
 * V)  
 *     0
 *     10
 *     010
 *     1010
 *     01010
 */
import java.util.*;
public class pat10
{
    public static void main()
    {
        int i,j,v=1,c=15,ch;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER 1 FOR PAT 1 \n ENTER 2 FOR PAT 2 \n ENTER 3 FOR PAT 3 \n ENTER 4 FOR PAT 4 \n ENTER 5 FOR PAT 5 ");
         ch=sc.nextInt();
        switch(ch)
        {
            case 1:
                for(i=1;i<=9;i+=2)
                {
                    for(j=i;j>=1;j-=2)
                    System.out.println(j);
                    System.out.println();
                }
                break;
                case 2:
                   for(i=5;i>=1;i--)
                {
                    for(j=1;j<=i;j++)
                    System.out.println((v++)+" ");
                    System.out.println();
                } 
                case 3:
                   for(i=5;i>=1;i--)
                {
                    for(j=1;j<=i;j++)
                    System.out.println((c--)+" ");
                    System.out.println();
                } 
                  case 4:
                   for(i=1;i<=5;i++)
                 {
                    for(j=1;j<=i;j++)
                    System.out.println(j%2);
                    System.out.println();
                } 
                  case 5:
                   for(i=2;i<=6;i++)
                {
                    for(j=i;j>=2;j--)
                    System.out.println(j%2);
                    System.out.println();
                } 
                break;
                default:System.out.println("wrong choice, try again");
    }
}
}