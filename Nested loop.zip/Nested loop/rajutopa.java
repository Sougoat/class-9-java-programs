/**
1
31 
531 
7531 
97531
 */ 
class rajutopa
{
    public static void main()
    {
        int i,j;
        for(i=1;i<=10;i=+2)
        {
            for(j=i;j<0;j=+2)
            {
            system.out.print(j);
        }
        system.out.println();
    }
}
}