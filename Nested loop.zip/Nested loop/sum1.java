/**
 * Wap in java to display the following series according to user's choice
 * 
 * i) s=2-4+6-8+............+20
 * ii) s=(1*2)+(2*3)+(3*4)+.....................(19*20)
 * iii) s=x/2+x/5+x/8+..................x/20
 */
import java.util.*;
public class sum1
{
    public static void main()
    {
        int ch,s=0,i,j;
        double s1=0.0,s2=0.0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1 for series 1 \n Enter 2 for series 2 \n Enter 3 for series 3 ");
        ch=sc.nextInt();
        switch(ch)
        {
                case 1:
                for(i=1;i<=10;i++)
                {
                    if(i%2==0)
                    s1=s1-(i*2);
                    else
                    s1=s1+(i*2);
                }
                System.out.println("THE SUM OF FTHE SERIES IS "+s1);
                break;
                case 2:
                for(i=1;i<=19;i++)
                {
                    s2=s2+(i*(i+1));
                    
                }
                System.out.println("THE SUM OF FTHE SERIES IS "+s2);
                break;
                case 3:
                    int x=0;
                    double s3=0.0;
                     System.out.println("ENTER THE VALUE OF X ");
                     x=sc.nextInt();
                for(i=2;i<=20;i+=3)
                {
                    s3=s3+(double)(x/i);

                    
                }
                System.out.println("THE SUM OF FTHE SERIES IS "+s3);
                break;
                default:System.out.println("WRONG CHOICE TRY AGAIN");
        }
    }
}