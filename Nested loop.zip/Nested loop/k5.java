/**
 * 
 * WRITE A MENU DRIVEN PROGRAM TO DISPLAY THE FOLLOWING PATTERN
 * CASE 1
 * 54321
 * 5432
 * 543
 * 54
 * 5
 * 
 * CASE 2
 *      *
 *      *#
 *      *#*
 *      *#*#
 *      *#*#*
 * 
 */
import java.util.*;
public class k5
{
    public static void main()
    {
        int i,j,ch;
        Scanner sc = new Scanner(System.in);
        do
        {
        System.out.println("ENTER 1 FOR PAT 1 \n ENTER 1 FOR PAT 2");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
            for(i=1;i<=5;i++)
            {
                for(j=5;j>=i;j--)
                {
                    System.out.print(j+" ");
                }
                 System.out.println("");
            }
            break;
            case 2:
            for(i=1;i<=5;i++)
            {
                for(j=1;j<=i;j++)          
                {
                    if(j%2==0)
                    
                    System.out.print("#");
                    else
                    System.out.print("*");
                }
                 System.out.println("");
            }
            break;
            case 0:
                break;
                default:
                    System.out.println("WRONG CHOICE TRY AGAIN");
        }
    }while(ch!=0);
}
}
        
        
        
        
        
        
