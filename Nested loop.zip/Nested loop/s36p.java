//print the series 1,11,111,1111,11111...... upto 10 terms 
public class s36p
{
public static void main()
{
int i,a=1;
for(i=1;i<=10;i++)
{
System.out.print(a+" ");
a=(a*10)+1;
}
}
}