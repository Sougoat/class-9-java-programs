/**
 * WAP IN JAVA TO DISPLAY THE FOLLOWING PATTERN ACCORDING TO USERS CHOICE
 * 
 * CASE A
 *  #@#@#
 *   @#@#
 *    #@#
 *     @#
 *      #
 * 
 * CASE B
 * 
 *   0
 *   1 1
 *   2 3 5
 *   8 13 21 24
 * 
 * 
 */

import java.util.*;
public class roddur
{
    public static void main()
    {
        char ch=' ';
        int i,j,sp,k;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER 1 FOR PATTERN 1 /t ENTER 2 FOR PAT 2 ");
        ch=sc.next().charAt(0);
        switch(ch)
        {
            case 'A':
                sp=0;
                for(i=5;i>=1;i--)                               //  sp      i       j       k       out
                {                                               //  0       5      1-0      5-1     #@#@#
                      for(j=1;j<=sp;j++)                        //  1       4      1-1      4-1      @#@# 
                                                               //   2       3      1-2      3-1       #@#       
                          System.out.print(" ");
                      
                          for(k=i;k>=1;k--)
                          {
                          if(k%2!=0)
                          System.out.print("#");
                          else
                          System.out.print("@");
                      }
                      sp++;
                      System.out.println("");
                }
                break;
                case 'B':
                    
                   int a=0,b=1,c;
                   for (i=1;i<=4;i++)
                    
                    {
                         for (j=1;j<=i;j++)
                         {
                             c=a+b;
                             System.out.print(a+" ");
                             a=b;
                             b=c;
                         }
                           System.out.println("");
                    }
                    break;
                    default:
                         System.out.println("wrong choice try again");
        }
    }
}