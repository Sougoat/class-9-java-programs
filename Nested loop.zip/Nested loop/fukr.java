/**
#@#@# 
@#@# 
#@# 
@# 
# 
 */
public class fukr
{
    public static void main()
    {
        int i,j;
        for(i=5;i>=1 ;i--)
    {
        for(j=1;j>=i;j--)
        {
            if(j%2==0)
                {
                    System.out.print("@");
                    
                }
                else
                {
                     System.out.print("#");
                }
            }
             System.out.println(" ");
        }
    }
}
