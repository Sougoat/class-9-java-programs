/**
#@#@# 
@#@# 
#@# 
@# 
# 
 */


public class p9
{
    public static void main()
    {
        int i,j;
        for(i=5;i>=1;i--)
        {
            for(j=i;j>=1;j--)
            {
                if(j%2==0)
                {
                    System.out.print("@");
                    
                }
                else
                {
                     System.out.print("#");
                }
            }
             System.out.println(" ");
        }
    }
}