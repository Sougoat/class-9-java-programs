public class x1
{
    public static void main()
    {
        int m=2,n=15,i;
        for(i=1;i<5;i++)
        {
            m++;
            --n;
        }
        System.out.println("The value of m becomes "+m);
        System.out.println("The value of n becomes "+n);
        
    }
}