/**
 * WAP A MENU DRIVEN PROGRAM TO DISPLAY THE FOLLOWING 
 * 1)ACCEPT ANY TWO NUMBERS AND DISPLAY THEIR GCD(GREATEST COMMON DIVISOR) 
 * GCD= DIVIDE THE LARGER BY THE SMALLER,THE REMAINDER THEN DIVISE THE PREVIOUS DIVISOR
 * THE PROCESS REPEATS UNLESS THE REMAINDER RECHES TO 0
 * EX-45,20
 * OUTPUT GCD=5
 * 
 * 2)
 * DISPLAY THE SERIES S=1+2^2/a+3^3/a^2+......N TERMS
 * 
 */
import java.util.*;
public class GCD
{
    public static void main()
    {
        int ch=0,a,b,t,n;
        double s=1.0;
        Scanner sc = new Scanner(System.in);
         System.out.println(" ENTER 1 FOR GCD \n ENTER 2 FOR SERIES  ");
         ch=sc.nextInt();
         switch(ch)
         {
             
         case 1:
         System.out.println(" ENTER THE FIRST NUMBER ");
         a=sc.nextInt();
         System.out.println(" ENTER THE SECOND NUMBER ");
         b=sc.nextInt();
         
         while(b>0)
         {
             t=b;
             b=a%b;
             a=t;
         }
          System.out.println(" THE GCD OF THE TWO NUMBVERS IS "+a);
          break;
         case 2:
             int i;
        System.out.println(" ENTER THE LIMIT ");
         n=sc.nextInt();
         System.out.println(" ENTER THE VALUE ");
         a=sc.nextInt();
         
         for(i=2;i<=n;i++)
         {
             s=s+Math.pow(i,i)/Math.pow(a,i-1);
             
         }
          System.out.println(" THE SUM IS "+s);
         break;
         default:
              System.out.println(" WRONG CHOICE TRY AGAIN ");
            }
        }
        }
              
         
         