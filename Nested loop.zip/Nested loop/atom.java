/**
 * WAP TO CREATE A FUNCTION INT REV(INT N)
 * VOID MAIN(INT N) TO CHEAK WHEATHER THE NUMBER IS A ATOMIC NUMBER OR NOT
 * ATOMIC NUMBER OR UNION NUMBER
 * EX 12
 * SQ OF 12 = 144
 * REV OF 12 IS 21 SQ OF 21 IS 441
 * REV OF 144 IS 441
 */
import java.util.*;
class atom 
{
    int Rev(int n)
    {
        int d,r=0;
        while (n>0)
        {
            d=n%10;
            r=(r*10)+d;
            n=n/10;
        }
        return r;
    }
    void main()
    {
    int m,sq,rsq;
    Scanner sc = new Scanner(System.in);
    System.out.println("ENTER A NUMBER");
    m=sc.nextInt();
    sq=m*m;
    rsq=Rev(sq);
    double sqt=Math.sqrt(rsq);
    int rsqt = Rev((int)sqt);
    if(rsqt-m==0)
    {
        System.out.println("NUMBER IS A ATOMIC NUMBER");
    }
        else
        {
        System.out.println("NUMBER IS NOT A ATOMIC NUMBER");
    }
    }
}
