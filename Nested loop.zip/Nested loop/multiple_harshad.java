/**
 * a number is said to be multiple_harshad number 
 * when divided by the sum of its digits produces another harshad number
 * 6804=6+8+0+4=18
 * 6804/18=378
 * 378=3+7+8=18
 * 378/18=21
 * 21=2+1=3
 * 21/3=7
 * 
 */
import java.util.*;
public class multiple_harshad
{
    public static void main()
    {
        int num,div,dd,count=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER A NUMBER");
        num=sc.nextInt();
        int n = num;
        while(n>1)
        {
            div=0;
            int t=n;
            while (t>0)
            {
                int d=t%10;
                div=div+d;
                t=t/10;
            }
            if((n%div==0) && (div!=1))
            {
                n=n/div;
                count++;
            }
            else
            {
                break;
            }
            }
            if(n==1 && count>1)
            System.out.println(num+" IS A MULTIPLE HARSHAD NUMBER ");
            else
            System.out.println(num+" IS NOT A MULTIPLE HARSHAD NUMBER ");
        }
        }
       