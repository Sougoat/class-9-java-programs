/**
    1
   00
  111
 0000
11111

i           j           k       out
1           4           1-1         1
2           3           1-2        00    
3           2           1-3       111     

 */
public class k7
{
   public static void main()
   {
       int i,j,k;
       for (i=1;i<=5;i++)
       {
           for(j=5-i;j>=1;j--)
           {
               System.out.print(" ");
           }
           for(k=1;k<=i;k++)
           {
               System.out.print(i%2);
               
           }
           System.out.println();
       }
   }
}