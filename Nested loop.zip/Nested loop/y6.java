/**
1 
01 
101 
0101 
10101 

    i                 j                   out
    1                1-1                   1
    2                1-2                   01
    3                1-3                   101
    4                1-4                   0101


 */
public class y6
{
    public static void main()
    {
        int i,j;
        for(i=1;i<=5;i++)
        {
            for(j=1;j<=i;j++)
            {
               
                if(i%2==j%2)
                System.out.print("1");
                else
                System.out.print("0");
            }
            System.out.println(" ");
        }
    }
}