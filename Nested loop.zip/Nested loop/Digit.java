/**
 * WAP TO ACCEPT A NUMBER AND COUNT THE NUMBER OF DIGITS. THE PROGRAM ALSO CHECK WHEATHER THE NUMBER 
CONTAINS ODD NUMBER OF DIGIT OR EVEN NUMBER OF DIGITS
EX- 749
OUT NO OF DIGITS = 3
THE NUMBER CONTAINS ODD NUMBER OF DIGITS 
 */
import java.util.*;
public class Digit
{
    public static void main()
    {
        int n,d=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number ");
        n=sc.nextInt();
    while(n>0)
    {
        d++;
        n=n/10;
    }
    System.out.println("The number of digits >> "+d);
    if(d%2==0)
    {
        System.out.println("The number contains even no of digits ");
        
    }
    else
    {
        System.out.println("The number contains odd no of digits ");
        
    }
}
}

    
      
    
