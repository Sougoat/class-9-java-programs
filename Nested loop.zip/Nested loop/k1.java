/**
 * display the pattern
1
22
333
4444
55555

 */
public class k1
{
    public static void main()
    {
        int i,j;
        for(i=1;i<=5;i++)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print(i);
                
            }
            System.out.println();
        }
    }
}


/**     outer loop - i
 *      i               j               out
 *      1               1-1             1
 *      2               1-2             22
 *      3               1-3             333
 *      4               1-4             4444
 *      5               1-5             55555
 */




