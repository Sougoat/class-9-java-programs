/**
 * WAP TO ACCEPT A BINARY NUMBER AND DISPLAY ITS DECIMAL EQUAVALENT
 */
import java.util.*;
public class BIN_TO_DEC
{
    public static void main()
    {
        int n=0,bin,t;
        double dec=0.0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER A BINARY NUMBER");
        bin=sc.nextInt();
        while(bin>0)
        {
            t=bin%10;
            dec=dec+t*Math.pow(2,n);
            bin=bin/10;
            n++;
            
        }
        System.out.println("the equevalent decimal number is "+dec);
    }
}