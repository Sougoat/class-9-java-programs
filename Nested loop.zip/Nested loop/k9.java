
/**
 1
 12
  123
   1234
    12345


 */
public class k9
{
   public static void main()
   {
       int i,j,k,sp=0;
       for (i=1;i<=5;i++)
       {
           for(j=1;j<=sp;j++)
           {
               System.out.print(" ");
           }
           for(k=1;k<=i;k++)
           {
               System.out.print(k);
               
           }
           sp++;
           System.out.println();
       }
   }
}