/**
 * s=1+a^2/1!+a^3/2!+a^4/3!+.......n
 */
import java.util.*;
public class s7
{
    int Fact(int n)
    {
        int f =1,i;
        for(i=1;i<=n;i++)
        {
            f=f*i;
        }
        return f;
    }
    
    void main()
    {
        int a,t,i;
        double s=0.0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER THE VALUE OF T");
        t=sc.nextInt();
        System.out.println("ENTER THE VALUE OF A");
        a=sc.nextInt();
        for(i=1;i<=t;i++)
        {
            s=s+(double)(Math.pow(a,(i+1)))/Fact(i);
                    
            }
            System.out.println("the sum of the series is "+s);
        }
    }
    
    
    
    
    
