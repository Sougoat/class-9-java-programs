public class s878
{
public static void main()
{

 for(int i=1;i<=6;i++)  
 {
     for(int j=1;j<=i;j++)
    System.out.print(5);
 System.out.print(' ');
                }
}
}

