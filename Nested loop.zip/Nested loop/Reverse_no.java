/**
 * Wap to accept a number and display its reverse form
 */
public class Reverse_no
{
    int Rev(int n)
    {
        int d=0,r=0,i;
        while(n>0)
        {
            d=n%10;
            r=(r*10)+d;
            n=n/10;
        }
        return r;
    }
}