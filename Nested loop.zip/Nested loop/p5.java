/**
 * The pattern
1 
3 5 
7 9 11 
13 15 17 19 
21 23 25 27 29 
p       a           b           out
1       1           1-1         1
3       2           1-2         3   5
5       3           1-3         7   9   11
7       4           1-4         13  15  17  19

 */

public class p5
{
    public static void main()
    {
        int a,b,p=1;
        System.out.println("The pattern");
        for(a=1;a<=5;a++)
        {
           for(b=1;b<=a;b++)
            {
                System.out.print(p+" ");
                p=p+2;
            }
         System.out.println();
        }
        
    }
}