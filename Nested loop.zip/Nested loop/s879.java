public class s879
{
public static void main()
{
 for(int i=1;i<=5;i++)      
     {
    for(int j=1;j<=i;j++)
    System.out.print((((i%2)==0)?'*':'#'));
    System.out.println();
      }
            
}
}
