/** WAP IN JAVA TO DISPLAY THE FOLLOWING ACCORDING TO USER'S CHOICE
 * DUCK NUMBER = IT IS A NUMBER WHERE A ZERO IS PRESENT IN THE NUMBER BUT THAT NUMBER SHOULD NOT BE
 * STARTED WITH ZERO
 * EX - 1025, 7806, 9630 ECT
 * 
 * PERFECT NUMBER = IT IS A NUMBER WHERE THE SUM OF THE FACTORS IS THE NUMBER ITSELF (INCLUDING 1 
 * BUT EXCLUDING THE NUMBER ITSELF)
 * EX - 6, 28
 */
import java.util.*;
public class MenuDuckPerfectNum
{
    public static void main()
    {
        //Variable Declarations.
        int n,d,i,ch,c=1,s=0;
        //Scanner object creation.
        Scanner sc = new Scanner(System.in);
        //Accepting user choice.
        System.out.println("Enter (1) for Duck Number\nEnter (2) for Perfect Number");
        System.out.println("Enter your choice : ");
        ch = sc.nextInt();
        switch(ch)
        {
            case 1:
            /* This block takes an integer input from the user and
             * and checks whether its a Duck No. or not.
             */
            System.out.println("Enter a number : ");
            n = sc.nextInt();
            int cp = n;
            while(n>0)
            {
                d=n%10;
                c=c*d;
                n=n/10;
            }
            //Printing whether the number is Duck or not.
            if(c==0)
            System.out.println(cp+" is a Duck Number.");
            else
            System.out.println(cp+" is not a Duck Number.");
            break;
            
            case 2:
            /* This block takes an integer input from the user and
             * and checks whether its a Perfect No. or not.
             */
            System.out.println("Enter a number : ");
            n = sc.nextInt();
            for(i=1;i<n;i++)
            {
                if(n%i==0)
                s=s+i;
            }
            //Printing whether the number is Perfect or not.
            if(s==n)
            System.out.println(n+" is a Perfect Number.");
            else
            System.out.println(n+" is not a Perfect Number.");
            break;
            
            default:
            System.out.println("WRONG CHOICE. TRY AGAIN...");
        }
    }
}