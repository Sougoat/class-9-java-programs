
/**
 wap to display the first 10 numbers in the fibonacci series
 out-0 1 1 2 3 5 8 13 21 34 55 89
 */
public class fibonacci
{
    public static void main()
    {
        int a = 0,b=1,c=0,i;
        System.out.print(a+" "+b);
        for(i=1;i<=10;i++)
        {
            c=a+b;
            
             System.out.print(" "+c);
             a=b;
             b=c;
        }
    }
}
    