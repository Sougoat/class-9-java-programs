/**WAP TO ACCEPT A NUMBER AND CHECK WHEATHER THE NUMBER IS A SUM PRODUCT NUMBER OR NOT 
 * SUM PRODUCT NUMBER = IS A NUMBER SUCH THAT THE PRODUCT OF SUM OF DIGITS AND THE PRODUCT OF THE DIGITS = THE ORIGINAL NUMBER
 * EXAMPLE 135=
 * SUM OF THE DIGTS (S)=1+3+5=9
 * PRODUCT OF THE DIGITS (P)=1*3*5=15
 * PRODUCT OF S*P=9*15=135
 */
public class sum_product
{
    public static void main(int n)
    {
        int d,s=0,p=1,t;
        t=n;
        while(t>0)
        {
            d=t%10;
            s=s+d;
            p=p*d;
            t=t/10;
        }
        if((s*p)==n)
        {
            System.out.println(n+" is a sum product number");
            
            
        }
        else
        {
            System.out.println(n+" is not a sum product number");
        }
    
    }
}
    
