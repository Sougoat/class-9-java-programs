/**
 * WAP TO ACCEPT A NUMBER AND CHEDCK WHEATHER IT IS A AUTOMORPHIC NUMBER OR NOT
 * AUTOMORPHIC NUMBER IS A NUMBER WHOSE SQ HAS THE SAME DIGITS IN THE END AS THE NUMBER ITSELF
 * EX-625=25,5
 *    76=76*76=5776
 */
import java.util.*;
public class automorphic
{
    public static void main()
    {
        int n,c=0,p,sq=0;
        double x=0.0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER A NUMBER");
        n=sc.nextInt();
        p=n;
        while(p>0)
        {
            p=p/10;
            c++;
        } sq=n*n;
        x=(sq%(int)Math.pow(10,c));
        if(x==n)
         System.out.println(n+" IS A AUTOMORPHIC NUMBER ");
         else
         System.out.println(n+" IS A NOT AUTOMORPHIC NUMBER ");
    }
}
