/**
 * WAP TO ACCEPT A THREE DIGIT NUMBER AND PRINT ONLY THE PRODUCT OF FIRST AND LAST DIGIT
 * 
 */
import java.util.*;
public class three_product
{
public static void main()
{
 int n,fd=0,ld=0,p=1;
 Scanner sc = new Scanner(System.in);
 System.out.println("ENTER A NUMBER");
 n = sc.nextInt();
 ld=n%10;
 while(n>0)
 {
     fd=n%10;
     n=n/10;
 
    }  System.out.println("THE FIRST DIGIT OF THE NUMBER IS "+fd);
       System.out.println("THE LAST DIGIT OF THE NUMBER IS "+ld);
       System.out.println("THE PRODUCT OF FIRST AND LAST DIGIT IS "+(fd*ld));
       
}
}