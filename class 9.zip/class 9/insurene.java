/** AN INSURENCE COMPANY HAS DECLARED THE BONUS ON YEARLY BASIS ON TWO TYPES POLICIES OR PLANS ON THE BASIS OF 
 * PREMIUM AMOUNT ON YEARLY BASIS PAID ONE TIME AS PER THE GIVEN CRITERIA
 * PREMIUM AMOUNT (IN RS.)              CHILD PLAN              NORMAL PLAN
 * MINIMUM AMOUNT 5000                      3%                      1.5%
 * 5001-20000                               5%                      3.5%
 * 20001 - 45000                            7%                      6.0%
 * 45001 AND ABOVE                          10%                     8.5%
 * WRITE A PROGRAM BASED ON ABOVE CRITERIA, TO ACCEPT NAME OF A PERSON, ADDRESS, PREMIUM AMOUNT (ONE TIME),
 * NO OF YEARS THE POLICY / PLAN OPTED FOR AND THE TYPE OF THE PLAN ( 'C' FOR CHILD AND 'N' FOR NORMAL). CALCULATE
 * THE BONUS AMOUNT FOR A YEAR AND ALSO FOR TOTAL NO OF YEARS THE POLICY OPTED FOR. CALCULATE THE MATURITY AMOUNT
 * AS FOLLOWS :-
 * BONUS IN ONE YEAR = (RATE PERCENTAGE 100) * PREMIUM
 * BONUS FOR NO OF YEARS = BONUS IN ONE YEAR * NO OF YEARS
 * MATURITY AMOUNT = PREMIUM AMOUNT + BONUS DEPENDING UPON THE YEARS
 * PRINT THE NAME OF THE PERSON, ADDRESS, PREMIUM AMOUNT, NO OF YEARS THE POLICY OPTED FOR, NAME OF THE PLAN,
 * TOTAL BONUS AND MATURITY AMOUNT
 * 
 */  
import java.util.*;
public class insurene
{
public static void main()
{
String p=" ",add=" ";
int pm=0,y;
char t=' ';
double r=0.0,bs=0.0,bt=0.0,net=0.0;
Scanner sc=new Scanner(System.in);
System.out.println("Enter a name of a person ");
p=sc.nextLine();
System.out.println("Enter a address of a person ");
add=sc.nextLine();
System.out.println("Enter the premium amount of a person ");
pm=sc.nextInt();
System.out.println("Enter the no of years the policy is opted for ");
y=sc.nextInt();
System.out.println("Enter the name of the plan ");
t=sc.next().charAt(0);

if(t=='C' || t=='c')
{
if(pm<=5000)
{
r=0.03;
}
else if(pm>5000 && pm<=20000)
{
r=0.05;
}
else if(pm>20000 && pm<=45000)
{
r=0.07;
}
else
{
r=0.01;
}
bs=pm*r;
bt=bs*y;
net=pm+bt;
System.out.println("Customer name \t address \t premium amount \t no of years ");
System.out.println(p+"\t\t"+add+"\t\t"+pm+"\t\t"+y);
System.out.println("policy Name \t Bonus -1st year \t Bonus - total \t Maturity Amount ");
System.out.println(t+"\t\t"+bs+"\t\t"+bt+"\t\t"+net);
}

else if(t=='N' || t=='n')
{
if(pm<=5000)
{
r=0.015;
}
else if(pm>5000 && pm<=20000)
{
r=0.035;
}
else if(pm>20000 && pm<=45000)
{
r=0.06;
}
else
{
r=0.085;
}
bs=pm*r;
bt=bs*y;
net=pm+bt;
System.out.println("Customer name \t address \t premium amount \t no of years ");
System.out.println(p+"\t\t"+add+"\t\t"+pm+"\t\t"+y);
System.out.println("policy Name \t Bonus -1st year \t Bonus - total \t Maturity Amount ");
System.out.println(t+"\t\t"+bs+"\t\t"+bt+"\t\t"+net);
}
else
{
System.out.println("The code is not recognizeed ");
}
}
}