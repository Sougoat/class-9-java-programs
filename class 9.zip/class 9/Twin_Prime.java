/**
 * Wap to accept any two numbers and check whether they are Twin_Prime nos are not.
 * Twin Prime nos = Both the numbers should be prime and their difference should be 2
 * ex - 17,19           71,73           29,31
 */
import java.util.*;
public class Twin_Prime
{
    public static void main()
    {
        int a,b,i,c=0,d=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the 1st number ");
        a=sc.nextInt();
        System.out.println("Enter the 2nd number ");
        b=sc.nextInt();
        for(i=1;i<=a;i++)
    {
        if(a%i==0)
        c++;
        
    }
     for(i=1;i<=b;i++)
    {
        if(b%i==0)
        d++;
        
    }
    if((c==2)&&(d==2) && a+2==b) 
    {
        System.out.println("THE NUMBERS "+a+" and "+b+" are twin prime numbers");
    
    }
    else
    {
     System.out.println("THE NUMBERS "+a+" and "+b+" are not twin prime numbers");
    }
    }
    }
