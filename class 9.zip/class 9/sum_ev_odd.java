/**
 * wap to accept a number and display the sum of even digits and product of odd digits separately 
 */
import java.util.*;
public class sum_ev_odd
{
    public static void main()
    {
        
        int n,d,s=0,p=1;
        
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER A NUMBER ");
        n=sc.nextInt();
        
        while(n>0)
        
        {
            d=n%10;
            if (d%2==0)
            {
                s=s+d;
            }
            else
            {
                p=p*d;
            }
            n=n/10;
        }
        System.out.println("the sum of even digits is "+s);
        System.out.println("the product of odd digits is "+p);
    }
}
