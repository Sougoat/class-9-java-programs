
/**
 * page no - 181 question - 16
 */

import java.util.*;
public class S1
{
    public static void main()
    {
        int l,b,h,ch;
        double pi=3.14,r=0.0,cu=0.0,cy=0.0,co=0.0;
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 1 for Cuboid \n Enter 2 for Cylinder \n Enter 3 for Cone ");
        System.out.println("Enter your choice");
        ch=sc.nextInt();
        
        switch(ch)
        {
            case 1:
                System.out.println("Enter the length of Cuboid ");
                l=sc.nextInt();
                System.out.println("Enter the breadth of Cuboid ");
                b=sc.nextInt();
                System.out.println("Enter the height of Cuboid ");
                h=sc.nextInt();
                
                cu=l*b*h;
                System.out.println("The volume of Cuboid is >> "+cu);
                break;
                
                case 2:
                System.out.println("Enter the radius of Cylinder ");
                r=sc.nextDouble();
                System.out.println("Enter the height of Cylinder ");
                h=sc.nextInt();
                cy=pi*r*r*h;
                 System.out.println("The volume of Cylinder "+cy);
                break;
                
                
                case 3:
                System.out.println("Enter the radius of Cone ");
                r=sc.nextDouble();
                System.out.println("Enter the height of Cone ");
                h=sc.nextInt();
                
                co=1.0/3.0*pi*r*r*h;
                 System.out.println("The volume of Cone "+co);
                break;
                
                default: System.out.println("Wrong choice, try again ");
                
            }
        }
    }
    
                
                
                
                
                
                
                
                
                
                
