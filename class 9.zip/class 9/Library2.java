/**
 * Define a class Library with the following 
 * String name : to accept the name of the book
 * int price : to accept the price of the book
 * int day : to accept the no of days the book is retained
 * 
 * double fine : To calculate the fine for the no of days late
 * The Library fine will be calculated as per the following
 * No of Days                                        Fine
 * for the first 7 days                         25 paise per day    
 * for the next 9 days                          40 paise per day
 * for the next 14 days                         60 paise per day
 * above 30 days                                80 paise per day
 * 
 */
import java.util.*;
public class Library2
{
    public static void main()
    {
        String name;
        int price;
        int day;
        double fine=0.0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the name of the book ");
        name=sc.next();
        System.out.println("Enter the price of the book ");
        price=sc.nextInt();
        System.out.println("Enter the no of days the book is retained ");
        day=sc.nextInt();
        if(day<=7)
        {
            fine=day*0.25;
            
        }
        
        else if(day>7 && day<16)
        {
            fine=(7*0.25)+(day-7)*0.40;
        }
        else if(day>16 && day<30)
        {
            fine=(7*0.25)+(9*0.40)+(day-16)*0.60;
        }
        else
        {
            fine=(7*0.25)+(9*0.40)+(14*0.60)+(day-30)*0.80;
        }
        System.out.println("Book name \t Price \t no of days \t Fine");
        System.out.println(name+"\t"+price+"\t\t"+day+"\t\t"+fine);
    }
}

        
        
        
        
        
        
        
        
        
    