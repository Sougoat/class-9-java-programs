/**
 * Wap to accept a number and display its sum of the digits
 * Ex- 457
 * out=4+5+7=16
 */

import java.util.*;
public class Sum_Digits
{
    public static void main()
    {
        int n,d,sum=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number ");
        n=sc.nextInt();
        while(n>0)
        {
            d=n%10;
            sum=sum+d;
            n=n/10;
            
        }
       System.out.println("The sum of the digits of the number is >> "+sum);
    }
}
