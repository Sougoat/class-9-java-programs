public class ran
{
    public static void main()
    {
        int n=10,a=5,b=20;
        double h=4.2;
        double p=-56.25;
        double t=Math.random();
        int k=(int)Math.random()*n+1;
        int g=(int)((Math.random()*(b-a))+a);
        double d=Math.ceil(h);
        double q=Math.sqrt(Math.abs(p));
        System.out.println("The random value of t is "+t);
       System.out.println("The random value of k is "+k);
       System.out.println("The random value of g is "+g);
         System.out.println("The value of d is "+d);
         System.out.println("The value of q is "+q);
    }
    }
