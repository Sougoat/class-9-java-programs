/**
 * WAP TO ACCEPT A NUMBER AND CHEACK WHEAHER IT IS A PERFECT SQUARE NUMBER OR NOT   
 * EX- 25 = 25*25= 625 WHICH CONTAINS THE ORIGINAL NUMBERS 25
 * 
 */
import java.util.*;
public class perfect_sq
{
    public static void main()
    {
        int n;
        double r=0.0;      
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER THE NUMBER");
        n=sc.nextInt();
        int d=n*n;
        r=Math.sqrt(d);
        if (n==r)
        {
            System.out.println("IS A PERFECT SQUARE NUMBER ");
        }
            else
            {
             System.out.println("IS NOT A PERFECT SQUARE NUMBER ");
            
            }
}
}