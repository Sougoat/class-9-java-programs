/**
 * PREPAID TAXI FARE 
 * WAP TO ACCEPT TAXY NUMBER AND DISTANCE COVERED 
 * THE FARE WILL BE CALCULATED AS PER THE FOLLOWING
 * DISTANCE(in KM)                                FARE(in rs)
 * for the first 5km                                 100
 * for the next 10km                               RS.10/km
 * for the next 10km                               RS.8/km
 *  more than 25km                                 RS.5/km
 */
import java.util.*;
public class prepaid_taxi
{
    public static void main()
    {
        String taxi=" ";
        int d = 0,fare=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER THE TAXI NUMBER");
        taxi=sc.next();
        System.out.println("ENTER THE DISTANCE COVERED");
        d=sc.nextInt();
        if(d<=5)
        {
            fare=100;
        }
        else if(d>5 && d<=15)
        {
            fare=100+(d-5)*10;
        }
        else if(d>15 && d<=25)
        {
            fare=100+100+(d-15)*8;
        }
        else
        {
            fare=100+100+80+(d-25)*5;
        }
        System.out.println("TAXI NUMBER IS "+taxi);
        System.out.println("THE DISTANCE COVERED IS "+d);
         System.out.println("THE FARE IS "+fare);
        }
    }
        
        
        
        
 