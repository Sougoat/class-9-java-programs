/**given  below the hypothetical table showing the rate of income tax for an Indian citizen, who is up to the age of 60 years
 * 
 * Taxable Income (TI) in Rs.                                               Income Tax in Rs.
 * upto to 250000                                                                NIL
 * more than 250000 and less than or equal to 500000                            (TI-160000)*10%
 * more than 500000 and less than or equal to 1000000                       (TI-500000)*20%+34000
 * more than 1000000                                                        (TI-1000000)*30%+94000
 * 
 * wap to input the name, age and taxable inome of a person. If the age is more than 60 years then display the message "wrong category". if the age is less than or equal to 60 years then compute
 * and display the income tax payable along with the name of the tax payer, as per the table given above.
 * 
 * 
 */
import java.util.*;
public class tax
{
    public static void main()
    {
        String n=" ";
        double ti=0.0, tax=0.0;
        int age=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the name of person ");
        n=sc.next();
        System.out.println("Enter the age of person ");
        age=sc.nextInt();
        System.out.println("Enter the taxable income of person ");
        ti=sc.nextDouble();
        
        if(age>60)
        {
            System.out.println("wrong category");
        }
        else
        {
            if(ti<=250000)
            {
                tax=0.0;
            }
            else if(ti>250000 && ti<=500000)
            {
                tax=(ti-160000)*0.1;
            }
            
            else if(ti>500000 && ti<=1000000)
            {
                tax=(ti-500000)*0.2+34000;
            }
            else
            {
            tax=(ti-1000000)*0.3+94000;                
            }
        
            System.out.println("Name of person \t\t Taxable income \t\t  Tax");
             System.out.println(n+"\t\t"+ti+"\t\t"+tax);
            }
        }
    }
        
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            