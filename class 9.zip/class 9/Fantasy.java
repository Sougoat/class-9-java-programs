/**
 * Fantasyland has a computerised joyride at the following rates
 * 
 * Age                  Rate
 * Below 4              Free
 * 4-18                 Rs.30
 * 19-59                Rs.40
 * above 59             free
 * 
 * if 1000 people take the ride each day, Wap in jave to ask the user to enter his/her age and calculate and print
 * how many belong to each category and also the total ticket sale of the day
 */

import java.util.*;
public class Fantasy
{
    public static void main()
    {
        int i,age,a=0,b=0,c=0,d=0,tot=0,net=0;
        int ap=0,bp=0,cp=0,dp=0;
        Scanner sc=new Scanner(System.in);
        for(i=1;i<=20;i++)
        {
            System.out.println("Enter the age of passenger");
            age=sc.nextInt();
            if(age<=4)
            {
                a++;
            }
            else if(age>4 && age<=18)
            {
                b++;
            }
            else if(age>18 && age<=59)
            {
                c++;
            }
            else
            {
                d++;
            }
        }
        ap=0;
        bp=b*30;
        cp=c*40;
        dp=0;
        net=ap+bp+cp+dp;
        System.out.println("The number of passengers belong to 4 years of age "+a);
        System.out.println("The number of passengers belong to 5-18 years of age "+b);
        System.out.println("The number of passengers belong to 19-59 years of age "+c);
        System.out.println("The number of passengers belong to above 59 years of age "+d);
        System.out.println("The total net bill is >> "+net);
    
    }
    }
