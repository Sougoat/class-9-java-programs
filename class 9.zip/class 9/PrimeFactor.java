/** WAP TO PRINT THE PRIME FACTORS OF A NUMBER
 * 
 */


import java.util.*;
public class PrimeFactor
{
    public static void main()
    {
        //Scanner object creation.
        Scanner sc = new Scanner(System.in);
        //Accepting the user's number.
        System.out.println("Enter a number : ");
        int n = sc.nextInt();
        //Printing the prime factors of the number
        System.out.println("The Prime factors of "+n+" are :-");
        for(int i=2; n>1; i++)
        {
            while(n%i==0)
            {//This loop prints the prime factors.
                System.out.print(i+", ");
                n/=i;
            }
        }
    }
}