/**A promoter and Developer announces a special bonanza for early booking for the flats for their customers as per the following 
 * tariff
 * Category      Discount on price         Discount on Development charges
 * Ground floor      10%                                 8%
 * first floor       0.0%                               0.0%
 * second floor      5%                                  5% 
 * Third Floor       7.5%                                10%
 *    wap to input price, development charge and the category ('G' for ground floor, 'F' for first floor and so) calculate
 *    and display the total discount, price  of the flat after discount.
 */
import java.util.*;
public class prom907687
{
public static void main()
{
    char ch = ' ';
    double dp=0.0,cp=0.0,d=0.0,disc=0.0 ,dv=0.0 ,dc=0.0,net=0.0,tot=0.0;
    Scanner sc = new Scanner(System.in);
    System.out.println(" ENTER THE PRICE OF THE FLAT");
    cp = sc.nextDouble();
    System.out.println(" ENTER THE DEVOLOPMENT PRICE OF THE FLAT");
    dp = sc.nextDouble();
    System.out.println(" ENTER THE CATEGORY OF THE FLAT");
    dp = sc.next().charAt(0);
if  (ch =='g'||ch == 'G')
{
    d=0.1;
    dc=0.08;
}
else if  (ch =='f'||ch == 'F')
{
    d=0.0;
    dc=0.0;
}
else if  (ch =='s'||ch == 'S')
{
    d=0.05;
    dc=0.5;
}
else 
{
    d=0.075;
    dc=0.1;
}
disc=cp*d;
dv=dc*dc;
tot=disc+dv;
net=(cp-disc)+(dp-dv);
        System.out.println("Cost Price \t Development Charge \t disc on price \t disc on Development");
        System.out.println(cp+"\t\t"+dp+"\t\t"+disc+"\t\t"+dv);
        System.out.println("category \t Total discount \t Net Price");
        System.out.println(ch+"\t\t"+tot+"\t\t"+net);
    }
}




