/**
 * wap to accept a number and display its reverse form 
 * ex- 567
 * out- 765
 */
import java.util.*;
public class Reverse
{
    public static void main()
    {
        int n,d,rev=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number ");
        n=sc.nextInt();
        int t=n;
        while(n>0)
        {
            d=n%10;
            rev=(rev*10)+d;
            n=n/10;
        }
        System.out.println("The Original number is >> "+t);
       System.out.println("The Reverse number is >> "+rev);
    }
}
