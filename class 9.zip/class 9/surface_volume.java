/** 
 *  WAP in java to display the following using switch case
 *  i)Surface area of a cone
 *  ii)Volume of a cone
 *  iii)Surface area of a sphere
 *  iv) Volume of a sphere
 *  v) Surface area of a cylinder
 *  vi)Volume of a cylinder
 */
import java.util.*;
public class surface_volume
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter 1 for surface area of cone \n enter 2 for Volume of a cone \n enter 3 for Surface area of a sphere \n enter 4 for Volume of a sphere \n enter 5 Surface area of a cylinder \n enter 6 Volume of a cylinder \n Enter your choice : ");
        int ch=sc.nextInt();
        double p=3.14;
        switch(ch)
        {
            case 1:
                System.out.print("Enter the radius of the cone : ");
                double r=sc.nextDouble();
                System.out.print("Enter the height of the cone : ");
                double h=sc.nextDouble();
                double sa=p*r*(r+Math.pow((Math.pow(h,2)+Math.pow(r,2)),(1/2)));
                System.out.print("The surface area of the cone : "+sa);
                break;
            case 2:
                System.out.print("Enter the radius of the cone : ");
                double r2=sc.nextDouble();
                System.out.print("Enter the height of the cone : ");
                double h2=sc.nextDouble();
                double v=1.0/3.0*p*r2*r2*h2;
                System.out.print("The volume of the cone : "+v);
                break;
            case 3:
                System.out.print("Enter the radius of the sphere : ");
                double r3=sc.nextDouble();
                double a=4*(22/7)*(Math.pow(r3,2));
                System.out.print("The surface area of the sphere : "+a);
                break;
            case 4:
                System.out.print("Enter the radius of the sphere : ");
                double r4=sc.nextDouble();
                double v2=(4.0/3.0)*p*(Math.pow(r4,3));
                System.out.print("The volume of the sphere : "+v2);
                break;
            case 5:
                System.out.print("Enter the radius of the cylinder : ");
                double r5=sc.nextDouble();
                System.out.print("Enter the height of the cylinder : ");
                double h3=sc.nextDouble();
                double a2=2*p*r5*(r5+h3);
                System.out.print("The surface area of the cylinder : "+a2);
                break;
            case 6:
                System.out.print("Enter the radius of the cylinder : ");
                double r6=sc.nextDouble();
                System.out.print("Enter the height of the cylinder : ");
                double h4=sc.nextDouble();
                double v3=p*(Math.pow(r6,2))*h4;
                System.out.print("The volume of the cylinder : "+v3);
                break;
            default:
                System.out.println("Wrong Choice!Try again!");
        }
    }
}