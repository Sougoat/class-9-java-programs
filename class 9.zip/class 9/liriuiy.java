/**A promoter and Developer announces a special bonanza for early booking for the flats for their customers as per the following 
 * tariff
 * Category      Discount on price         Discount on Development charges
 * Ground floor      10%                                 8%
 * first floor       0.0%                               0.0%
 * second floor      5%                                  5% 
 * Third Floor       7.5%                                10%
 *    wap to input price, development charge and the category ('G' for ground floor, 'F' for first floor and so) calculate
 *    and display the total discount, price  of the flat after discount.
 */
import java.util.*;
public class promoter
{
    public static void main()
    {
        
        