/**
wap to accept a number and check wheather it is a niven number or not 
niven/harshad number it is a number divisible by the sum of its digits 
EX-18=1+8=9
   12,20,110,192 etc..
*/
import java.util.*;
public class bu6689
{
   public static void main()
   {
       int n,d,s=0;
       Scanner sc = new Scanner(System.in);
       System.out.println("ENTER A NUMBER");
       n=sc.nextInt();
       int t =n;
       while(n>0)
       {
       d=n%10;
       s=s+d;
       n=n/10;
       

   
