/**A promoter and Developer announces a special bonanza for early booking for the flats for their customers as per the following 
 * tariff
 * Category      Discount on price         Discount on Development charges
 * Ground floor      10%                                 8%
 * first floor       0.0%                               0.0%
 * second floor      5%                                  5% 
 * Third Floor       7.5%                                10%
 *    wap to input price, development charge and the category ('G' for ground floor, 'F' for first floor and so) calculate
 *    and display the total discount, price  of the flat after discount.
 */
import java.util.*;
public class rajutora
{
public static void main()
{
    int l,b,h,ch;
        double pi=3.14,r=0.0,cu=0.0,cy=0.0,co=0.0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 1 for Cuboid \n Enter 2 for Cylinder \n Enter 3 for Cone ");
        System.out.println("Enter your choice");
        ch=sc.nextInt();
        switch(ch)
        {
        case 1:
                System.out.println("Enter the length of Cuboid ");
                l=sc.nextInt();
                System.out.println("Enter the breadth of Cuboid ");
                b=sc.nextInt();
                System.out.println("Enter the height of Cuboid ");
                h=sc.nextInt();

                cu=l*b*h;
        System.out.println("The volume of Cuboid is >> "+cu);
                break;
                
                case 2:
                System.out.println("Enter the radius of Cylinder ");
                r=sc.nextDouble();
                System.out.println("Enter the height of Cylinder ");
                h=sc.nextInt();
                cy=pi*r*r*h;
                 System.out.println("The volume of Cylinder "+cy);
                break;
        case 3:
            System.out.println("enter the radious of cone ");
            r=sc.nextDouble();
            System.out.println("enter the height of cone ");
            h=sc.nextInt();
            co=1.0/3.0*pi*r*r*h;      
            System.out.println("the volume of cone is "+co ) ;       
            break;
            default:System.out.println("Wrong choice, try again ");
        }
    }
}
                
        
        
        
        
        
        
        
        
        


          