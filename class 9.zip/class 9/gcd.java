
/**
 wap to find the gcd of two numbers
 */
import java.util.*;
public class gcd
{
    public static void main()
    {
        
    
    int a,b,t=0;
    Scanner sc = new Scanner(System.in);
    System.out.println("ENTER THE FIRST NUMBER");
    a=sc.nextInt();
    System.out.println("ENTER THE SECOND NUMBER");
    b=sc.nextInt();
    while(a%b!=0)
    {
        t=a%b;
        a=b;
        b=t;
        
    }
    System.out.println("the gcd of two numbers is "+b);
    
    
}
}