/**
 * WAP TO DISPLAY ALAL THE NUMBERS BETWEEN M AND N INPUT FROM THE KEYBOARD (WHERE M<N,M>0,N>0)
 * CHECK AND PRINT THEE NUMBERS THNAT AREE PERFECT SQUARE NUMBER
 * 25 36 49 
 */
import java.util.*;
public class perfect_sqare
{
    public static void main()
    {
        int n,m,i;
        double sq=0.0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER THE FIRST LIMIT");
        m=sc.nextInt();
        System.out.println("ENTER THE LAST LIMIT");
        n=sc.nextInt();
        if(m<n && m>0 && n>0)
        {
        for(i=m;i<=n;i++)
        {
            System.out.println("THE NUMBER IS "+i);
            sq=Math.sqrt(i);
            if(sq==Math.floor(sq))
            System.out.println(i+" THE NUMBER IS A PERFECT SQUARE ");
        }
    }else
    System.out.println("INVALID INPUT");
}
}

    