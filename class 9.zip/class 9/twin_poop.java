/**
 * Wap to accept any two numbers and check whether they are Twin_Prime nos are not.
 * Twin Prime nos = Both the numbers should be prime and their difference should be 2
 * ex - 17,19           71,73           29,31
 */


import java.util.*;
class twin_poop
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int a,s,r=0,h=0,i;
        System.out.println("Enter the first number");
        a=sc.nextInt();
         System.out.println("Enter the second number");
        s=sc.nextInt();
        for(i=1;i<=a;i++)
        {
            if(a%i==0)
            r++;
        }
        for(i=1;i<=s;i++)
        {
            if(s%i==0)
            h++;
        }
        if((a==2)  &&   (s==2) && a+2==s )
        {
            System.out.println("THE NUMBERS "+a+" and "+s+" are twin prime numbers");
    
    }
    else
    {
     System.out.println("THE NUMBERS "+a+" and "+s+" are not twin prime numbers");
    }
}
}