/**
 * WAP to input a set 0f numbers. The program checks each number wherther 
 * it is a positive even  or negative odd number. The loop should 
 * terminate when zero is entered by the user.
 */
import java.util.*;
public class pos_neg
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        int n,i;
        do
        {
            System.out.println("Enetr a number and zero to terminate");
            n=sc.nextInt();
            if(n==0)
            break;
            if(n>0 && n%2==0)
            System.out.println(n+" is a posetive even number");
            else
            System.out.println(n+" is a negative odd number");
        }
        while(true);
        System.out.println("Program Terminates!");
        
    }
}