/**
 * WAP in java toa accept a three digit number and print the product of first n last digit
 */
import java.util.*;
public class Pro_first_last
{
    public static void main()
    {
        int n,d=0,ld;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number ");
        n=sc.nextInt();
        ld=n%10;
        while(n>0)
        {
            d=n%10;
            n=n/10;
        }
        System.out.println("The first digit is "+d);
        System.out.println("The last digit is "+ld);
        System.out.println("The product of fd and ld is "+(d*ld));
    }
    
}