/**
 * Wap to accept a number and check whether the number is a palindromic number or not
 * palindrome number= it is a number which and when reversed also display the same number
 * ex= 131,171,121 etc
 */
import java.util.*;
public class palindrome
{
    public static void main()
    {
        int n,d,rev=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number ");
        n=sc.nextInt();
        int t=n;
        while(n>0)
        {
            d=n%10;
             rev=(rev*10)+d;
            n=n/10;
           
        }
        if(rev==t)
        {
            System.out.println(t+" is a Palindromic number");
        }
        else
        {
            System.out.println(t+" is not a Palindromic number");

        }
    }
}