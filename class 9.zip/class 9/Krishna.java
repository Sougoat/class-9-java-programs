/**
 * WAP TO ACCEPT A N8MBER AND CHECLK WHETHER A NUMBER IS A KRISNAMURTI OR SPECIAL NUMBER OR NOT
 * KRISNAMURTI NUMBER = IF THE SUM OF THE FACTORS OF EACH DIGITS IS EQUAL TPO THE OTRIGINAL NUMBER IS CALLED KRISNAMURTI NUMBER 
 * EX-145=1+24+120=145
 */


import java.util.*;
public class Krishna
{
    public static void main()
    {
        int i,n,f,d,s=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number ");
        n=sc.nextInt();
        int t=n;
        
        while(t>0)
        {
            d=t%10;
            f=1;
            for(i=1;i<=d;i++)
            {
                f=f*i;
               
            }
             s=s+f;
            t=t/10;
            
        }
        if(n==s)
        {
            System.out.println(n+" The number is a Krishnamurthy number ");
        }
        else
            System.out.println(n+" The number is not a Krishnamurthy number ");
        }
    }
        