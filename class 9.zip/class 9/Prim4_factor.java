/**
 * WAP TO ACCEPT A NUMBER AND DISPLAY THE SUM OF PRTIME FACTORS ONLY 
 * EX-12
 * PRIME FACTORS=2,3
 * SUM OF PRIME FACTORS = 2+3=5
 */
import java.util.*;
public class Prim4_factor
{
    public static void main()
    {
        int i,n,j,count,s=0,c=0;
        Scanner sc=new Scanner(System.in);
        
        System.out.println("ENTER A NUMBER ");
        n=sc.nextInt();
        for (i=2;i<n;i++)
        {
            if (n%i==0)
            {
                c=i;
                count=0;
                for(j=2;j<=c/2;j++)
                {
                    if (c%j==0)
                    count++;
                }
                if (count==0)
                s=s+c;
            
            }
        }
        System.out.println("sum of prime factors is "+s);
    }
}