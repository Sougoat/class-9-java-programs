/**
 * Wap to print all the Even numbers from 50 to 80 using continue loop
 */
public class con1
{
    public static void main()
    {
        int i;
        for(i=50;i<=80;i++)
        {
            if(i%2!=0)
            continue;
            System.out.print(i+" ");
        }
    }
}