

public class t
{
    public static void main()
    {
        int a=5;
        a++;
        System.out.println(a);
        a-=(a--)-(--a);
        System.out.println(a);
        
    }
}