
import java.util.*;

class tenary 
{
   public static void main()
   {
       int a,b,c,max=0,min=0;
       Scanner sc = new Scanner(System.in);
       System.out.println("ENTER THE FIRST NUMBER ");
       a = sc.nextInt();
       System.out.println("ENTER THE SECOND NUMBER ");
       b = sc.nextInt();
       System.out.println("ENTER THE THIRD NUMBER ");
       c = sc.nextInt();
       
       max=(a>b)?(a>c?a:c):(b>c?b:c);
       min=(a<b)?(a<c?a:c):(b<c?b:c);
       
       System.out.println("THE MAXIMUM OF THREE NUMBER IS  "+max);
       System.out.println("THE MINIMUM OF THREE NUMBER IS  "+min);

    }
}