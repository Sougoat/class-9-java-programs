/**
 * WITHOUT USING IF ELSE STATEMENT AND TERNARY OPERATOR ACCEPT THREE UNEQUAL NUMBER AND DISPLAY THE SECOND SMALLEST NUMBER 
 * EX-34,82,61
 * OUTPUT 61
 * 
 */
import java.util.*;
public class second_small
{
    public static void main()
    {
        int a,b,c,big=0,sml=0,out=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER THE FIRST NUMBER ");
        a=sc.nextInt();
        System.out.println("ENTER THE SECOND NUMBER ");
        b=sc.nextInt();
        System.out.println("ENTER THE THIRD NUMBER ");
        c=sc.nextInt();
        int sum=a+b+c;
        big=Math.max(a,b);
        big=Math.max(big,c);
        sml=Math.min(a,b);
        sml=Math.min(sml,c);
        out=sum-big-sml;
        System.out.println(" THE SECOND SMALLEST NUMBER IS "+out);
        
    }
}