/**wap to display the series from 1 to 30 using break statement
 * 
 */
public class b1
{
    public static void main()
    {
        int i;
        for(i=1;i<=30;i++)
        {
            if(i==25)
            break;
            System.out.println(i);
        }
    }
}