/**WAP TO ACCEPT ANUMBER AND CHECK WHEATHER A NUMBER IS SPY NUMBER OR NOT 
 * SPY NUMBER = IT IS ANUMBER WHERE THE  SUM OF ALL THE DIGITS IS EQUAL TO THE PRODUCT OF ALL THE DIGITS
 * EX-1124
 * SUM=1+1+2+4=8
 * PRODUCT=1*1*2*4=8
 */
import java.util.*;
public class spy_num
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int n,d,s=0,p=1;
        System.out.println("ENTER A NUMBER");
        n=sc.nextInt();
        int t=n;
        while(n>0)
        {
            d=n%10;
            s=s+d;
            p=p*d;
            n=n/10;
        }
        if(s==p)
        {
            System.out.println(t+" IS A SPY NUMBER");
        }
        else
        {
            System.out.println(t+" IS NOT A SPY NUMBER");
        
        
    
    }
}
}